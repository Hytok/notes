<form method="POST" enctype="multipart/form-data" action="<?php echo e(route('add_contact')); ?>">

</form>
<?php /**PATH C:\xampp\htdocs\notebook\resources\views/add_contact.blade.php ENDPATH**/ ?>