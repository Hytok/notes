<div class="popup-fade">
    <div class="popup">
        <a class="popup-close" href="#">X</a>
        <?php if($contacts->photo == NULL): ?>
            <img src="images/foto.png" style="width: 40%; margin-left: 30%; height: 250px; border-radius: 50%; margin-bottom: 10px;">
        <?php else: ?>
            <img src="images/<?php echo e($contacts->photo); ?>" style="width: 40%; margin-left: 30%; height: 250px; border-radius: 50%; margin-bottom: 10px;">
        <?php endif; ?>
        <table border="1" style="width: 100%;">
            <tr>
                <th>Фио:</th>
                <th>Электронная почта:</th>
                <th>Номер телефона:</th>
                <th>Дата рождения</th>
            </tr>
            <tr>
                <td><?php echo e($contacts->name); ?></td>
                <td><?php echo e($contacts->email); ?></td>
                <td><?php echo e($contacts->phone); ?></td>
                <td><?php echo e($contacts->data); ?></td>
            </tr>
            <tr>
                <th>Страна рождения:</th>
                <th>Город рождения:</th>
                <th>Facebook:</th>
                <th>Другие соц. сети:</th>
            </tr>
            <tr>
                <td><?php echo e($contacts->country); ?></td>
                <td><?php echo e($contacts->city); ?></td>
                <td><?php echo e($contacts->facebook); ?></td>
                <td><?php echo e($contacts->other_social); ?></td>
            </tr>
        </table>
        <div class="new_social"><h3>Другие соц. сети:</h3><button>Добавить другую соц. сеть</button></div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\notebook\resources\views/show.blade.php ENDPATH**/ ?>