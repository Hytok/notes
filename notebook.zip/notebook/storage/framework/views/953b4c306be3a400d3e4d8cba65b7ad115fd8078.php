

            <form enctype="multipart/form-data" action="<?php echo e(action ([\App\Http\Controllers\CountryController::class,'store'])); ?>" method="POST">

                <?php echo e(csrf_field()); ?>


                <div class="modal-body">

                    <div class="form-group">
                        <label>Название страны</label>
                        <input type="text" class="form-control" name="name" placeholder="country">
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Закрыть</button>
                    <button type="submit" class="btn btn-primary">Сохранить</button>
                </div>
            </form>

<form enctype="multipart/form-data" action="<?php echo e(action ([\App\Http\Controllers\CityController::class,'store'])); ?>" method="POST">

    <?php echo e(csrf_field()); ?>


    <div class="modal-body">

        <div class="form-group">
            <label>Название страны</label>
            <input type="text" class="form-control" name="name" placeholder="country">
        </div>

    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Закрыть</button>
        <button type="submit" class="btn btn-primary">Сохранить</button>
    </div>
</form>
<?php /**PATH C:\xampp\htdocs\notebook\resources\views/location.blade.php ENDPATH**/ ?>