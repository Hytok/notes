

<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Новый контакт</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <form enctype="multipart/form-data" action="<?php echo e(action ([\App\Http\Controllers\ContactController::class,'store'])); ?>" method="POST">

                <?php echo e(csrf_field()); ?>


                <div class="modal-body">

                    <div class="form-group">
                        <label>ФИО</label>
                        <input type="text" class="form-control" name="name" placeholder="name">
                    </div>

                    <div class="form-group">
                        <label>Номер телефона</label>
                        <input type="text" class="form-control" name="phone" placeholder="phone">
                    </div>

                    <div class="form-group">
                        <label>Email</label>
                        <input type="text" class="form-control" name="email" placeholder="email">
                    </div>

                    <div class="form-group">
                        <label>Дата рождения</label>
                        <input type="date" class="form-control" name="data" placeholder="data">
                    </div>

                    <div class="form-group">
                        <label>Facebook</label>
                        <input type="text" class="form-control" name="facebook" placeholder="facebook">
                    </div>

                    <div class="form_social">
                        <label>Другие соц. сети</label>
                        <div id="input0"></div>
                        <div class="add btn-success text-center" onclick="addInput()">Добавит дополнительную строку</div>
                    </div>

                    <select name="prefix" id="prefix" class="form-select">
                        <option value="0" id="default">Страна не выбрана</option>
                        <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $countries): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($countries->country_id); ?>" id="contry"><?php echo e($countries->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <div id="disappear" style="display: none">
                        <select id="city">
                            <?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cities): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option id="city<?php echo e($key); ?>" class="city" value="<?php echo e($cities->name); ?>,<?php echo e($cities->country_id); ?>"><?php echo e($cities->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div id="soc"></div>

                    <div class="form-group">
                        <label>Загрузить фото:</label>
                        <input type="file" class="form-control" name="photo"/>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Закрыть</button>
                    <button type="submit" class="btn btn-primary">Сохранить</button>
                </div>
            </form>
        </div>
    </div>
</div>


<div class="modal fade" id="showModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Карточка контакта</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <!--<form action="/index" method="POST" id="showForm">-->
            <form action="/" id="showForm">
                
                
                <div class="modal-body text-center">

                    <div class="form-group">
                        <label class="fw-bold">Фото</label>
                        <input id="photo" type="image" src="#" style="width: 100%">
                    </div>

                    <div class="form-group">
                        <label class="fw-bold">ФИО:</label>
                        <output type="text" class="form-control" id="name" name="name"></output>
                    </div>

                    <div class="form-group">
                        <label class="fw-bold">Номер телефона</label>
                        <output type="text" class="form-control" id="phone" name="phone"></output>
                    </div>

                    <div class="form-group">
                        <label class="fw-bold">Email</label>
                        <output type="text" class="form-control" id="email" name="email"></output>
                    </div>

                    <div class="form-group">
                        <label class="fw-bold">Дата рождения</label>
                        <output type="date" class="form-control" id="data" name="data"></output>
                    </div>

                    <div class="form-group">
                        <label class="fw-bold">Facebook</label>
                        <a type="text" class="form-control" id="facebook" name="facebook">Facebook</a>
                    </div>

                    <div class="form-group">
                        <label class="fw-bold">Страна</label>
                        <output type="text" class="form-control" id="country" name="country"></output>
                    </div>

                    <div class="form-group">
                        <label class="fw-bold">Город</label>
                        <output type="text" class="form-control" id="cities" name="city"></output>
                    </div>

                    <div class="form-group">
                        <label class="fw-bold">Другие соц. сети</label>
                        <div id="social"></div>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Закрыть</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php /**PATH C:\xampp\htdocs\notebook\resources\views/modal.blade.php ENDPATH**/ ?>